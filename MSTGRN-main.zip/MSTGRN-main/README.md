# MSTGRN
Traffic Forecasting
## Datasets 
链接：https://pan.baidu.com/s/1Gqc_ROajn-hsxd87CSvQbQ?pwd=1234 
提取码：1234
## Generating training data
eg: !python generate_data.py --dataset PEMS08
## Run in the model folder
eg: !python train.py --dataset PEMS08
